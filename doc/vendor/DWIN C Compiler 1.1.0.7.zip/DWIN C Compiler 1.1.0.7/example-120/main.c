/************************************file start*******************************************/
int TIM_SYS=0;
unsigned char uart6_read[256];
int uart6_rx_head=0,uart6_rx_tail=0;

void cs_define(void)
{
	int a,b;
	a=A;
	a+=A;
	write_dgus_vp(0x1280,&a,2);
	a+=B;
	write_dgus_vp(0X1282,&a,2);
	a=C(100,200,300);
	write_dgus_vp(0X1284,&a,2);
	b=B;
	D(a,b);
	write_dgus_vp(0x1286,&a,2);
	write_dgus_vp(0x1288,&b,2);
	b=3;
	E(a,b);
	write_dgus_vp(0x128a,&a,2);
}

int main()
{
    char data;
    int ii=0,len,x;
    char vp_data[4]={0x5a,0x01,0x00,0x01};
    char vp_data_read[4]={0};
    char lib_data[10]={0x5A,0X00,0X18,0X00,0XE0,0X00,0X08,0X00};
	//float型数定义
    float bonus1,bonus2,bonus4,bonus6,bonus10,bonus,i;
	//define tests
	cs_define();
    //VP操作
	//dgus_page(1);								//VP操作--页面切换
	write_dgus_vp(0x1280,vp_data,2);			//VP操作-写
	read_dgus_vp(0x1280,vp_data_read,2);		//VP操作-读
	//中断配置，接口寄存器操作
    data=0xC0;
	write_register(45,&data);					//设置中断
	data=10;
	write_register(46,&data);					//定时器0设置
	//IO口设置
	IOconfig(0x0003FDFF);						//IO口9为输入其他串口为输出
	//串口设置
	com_config(6,0,115200);						//串口6设置115200波特率
	//库文件加载到VP空间
	//load_lib(3,0xe000,1);						//3号库文件，文件在例程中
	//float型数据操作
	i=50000.3f;
    bonus1=100000*0.1f;							//浮点数计算
    bonus2=bonus1+100000*0.075f;
    bonus4=bonus2+200000*0.05f;
    bonus6=bonus4+200000*0.03f;
    bonus10=bonus6+400000*0.015f;	
    if(i<=100000.00f) {							//语句判定
        bonus=i*0.1f;
    } else if(i<=200000.00f) {
        bonus=bonus1+(i-100000.0f)*0.075f;
    } else if(i<=400000.00f) {
        bonus=bonus2+(i-200000.0f)*0.05f;
    } else if(i<=600000.00f) {
        bonus=bonus4+(i-400000.0f)*0.03f;
    } else if(i<=1000000.00f) {
        bonus=bonus6+(i-600000.0f)*0.015f;
    } else if(i>1000000.0f) {
        bonus=bonus10+(i-1000000.0f)*0.01f;
    }
    x=(int)bonus;								//类型强制转换
    write_dgus_vp(0x1288,&x,2);
	while(1){
		//串口处理部分
		len=com_data_len(6);
		while(len){
			com_data_read(6,&uart6_read[uart6_rx_head],1);
			uart6_rx_head=(uart6_rx_head+1) & 0XFF;			//接受头指针修改
			len--;
		}
		if(uart6_rx_head != uart6_rx_tail){
			send_data_com(6,&uart6_read[uart6_rx_tail],1);
			uart6_rx_tail=(uart6_rx_tail+1) & 0XFF;			//处理完毕之后接受尾指针处理
		}
		//IO口操作
		ii=read_io(9);							//读取IO口状态
		write_io(3,ii);							//写IO口状态
		write_io(5,ii);
		write_io(7,ii);
		//运行库文件
		//run_lib(0xe000);						//运行库文件，运行效果0X1280变量空间中的数据每个循环增加1
	}
    return 0;
}
//中断函数实体
void Time0_IRQHandler(void)
{
	TIM_SYS++;
}
void Time1_IRQHandler(void)
{
}
void Time2_IRQHandler(void)
{
}