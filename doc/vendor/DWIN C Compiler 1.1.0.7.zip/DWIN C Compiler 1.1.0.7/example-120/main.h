/************************************file start*******************************************/
#define A 100
#define B 200
#define C(x,y,z)	(x+y+z)
#define	D(x,y)	\
	if(x>y){	\
		x++;	\
	}else{		\
		y++;	\
	}
#define E(x,y)	\
	do{			\
		x++;	\
	}while(y--)