/************************************file start*******************************************/
void dgus_page(int page)
{
	char page_data[4]={0x5a,0x01,0x00,0x00};
	page_data[2]=(page >> 8) & 0xff;
	page_data[3]=page & 0xff;
	write_dgus_vp(0x0084,page_data,2);
}