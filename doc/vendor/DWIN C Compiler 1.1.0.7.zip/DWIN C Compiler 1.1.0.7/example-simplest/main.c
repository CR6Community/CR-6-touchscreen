/************************************file start*******************************************/
int main()
{
	return 0;
}
void Time0_IRQHandler(void)
{
}
void Time1_IRQHandler(void)
{
}
void Time2_IRQHandler(void)
{
}